<?php
define('TOP_STORE_TOP_HEADER_LAYOUT_1', TOP_STORE_THEME_URI. "customizer/images/top-header-1.png");
define('TOP_STORE_TOP_HEADER_LAYOUT_2', TOP_STORE_THEME_URI. "customizer/images/top-header-2.png");
define('TOP_STORE_TOP_HEADER_LAYOUT_3', TOP_STORE_THEME_URI. "customizer/images/top-header-3.png");
define('TOP_STORE_TOP_HEADER_LAYOUT_NONE', TOP_STORE_THEME_URI. "customizer/images/top-header-none.png");

define('TOP_STORE_MAIN_HEADER_LAYOUT_ONE', TOP_STORE_THEME_URI. "customizer/images/top-store-header-1.png");
define('TOP_STORE_MAIN_HEADER_LAYOUT_TWO', TOP_STORE_THEME_URI. "customizer/images/top-store-header-2.png");
define('TOP_STORE_MAIN_HEADER_LAYOUT_THREE', TOP_STORE_THEME_URI. "customizer/images/top-store-header-3.png");
define('TOP_STORE_MAIN_HEADER_LAYOUT_FOUR', TOP_STORE_THEME_URI. "customizer/images/top-store-header-4.png");

define('TOP_STORE_FOOTER_WIDGET_LAYOUT_1', TOP_STORE_THEME_URI. "customizer/images/widget-footer-1.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_2', TOP_STORE_THEME_URI. "customizer/images/widget-footer-2.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_3', TOP_STORE_THEME_URI. "customizer/images/widget-footer-3.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_4', TOP_STORE_THEME_URI. "customizer/images/widget-footer-4.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_5', TOP_STORE_THEME_URI. "customizer/images/widget-footer-5.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_6', TOP_STORE_THEME_URI. "customizer/images/widget-footer-6.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_7', TOP_STORE_THEME_URI. "customizer/images/widget-footer-7.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_8', TOP_STORE_THEME_URI. "customizer/images/widget-footer-8.png");
define('TOP_STORE_FOOTER_WIDGET_LAYOUT_NONE', TOP_STORE_THEME_URI. "customizer/images/widget-footer-none.png");
//pre-loader
define('TOP_STORE_PRELOADER', TOP_STORE_THEME_URI. "image/top-store-loader.gif");
//SLIDER
define('TOP_STORE_SLIDER_LAYOUT_2', TOP_STORE_THEME_URI. "customizer/images/slider-layout-2.png");
define('TOP_STORE_SLIDER_LAYOUT_3', TOP_STORE_THEME_URI. "customizer/images/slider-layout-3.png");
define('TOP_STORE_SLIDER_LAYOUT_4', TOP_STORE_THEME_URI. "customizer/images/slider-layout-4.png");
define('TOP_STORE_SLIDER_LAYOUT_1', TOP_STORE_THEME_URI. "customizer/images/slider-layout-1.png");
//category slider
define('TOP_STORE_CAT_SLIDER_LAYOUT_1', TOP_STORE_THEME_URI. "customizer/images/category-slider-1.png");
define('TOP_STORE_CAT_SLIDER_LAYOUT_2', TOP_STORE_THEME_URI. "customizer/images/category-slider-2.png");
define('TOP_STORE_CAT_SLIDER_LAYOUT_3', TOP_STORE_THEME_URI. "customizer/images/category-slider-3.png");
//Banner Slider
define('TOP_STORE_BANNER_IMG_LAYOUT_1', TOP_STORE_THEME_URI. "customizer/images/banner-image-1.png");
define('TOP_STORE_BANNER_IMG_LAYOUT_2', TOP_STORE_THEME_URI. "customizer/images/banner-image-2.png");
define('TOP_STORE_BANNER_IMG_LAYOUT_3', TOP_STORE_THEME_URI. "customizer/images/banner-image-3.png");
define('TOP_STORE_BANNER_IMG_LAYOUT_4', TOP_STORE_THEME_URI. "customizer/images/banner-image-4.png");
define('TOP_STORE_BANNER_IMG_LAYOUT_5', TOP_STORE_THEME_URI. "customizer/images/banner-image-5.png");